# Detalhes da Infraestrutura

## Sub-redes

- **frontend**: exposta a clientes internos
- **backend**: comunicação com SQL Server
- **jumpbox**: VM para administração segura via RDP ou SSH

## Dimensionamento das Máquinas

- **App Server**: Standard_B2ms (2vCPU, 8 GB RAM)
- **SQL Server**: Standard_D4s_v3 (4vCPU, 16 GB RAM)
- **JumpBox**: Standard_B1s

## Políticas de Segurança

- NSGs com regras de entrada e saída por sub-rede
- Acesso RDP restrito à subnet `jumpbox`
