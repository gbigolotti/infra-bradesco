# 🏦 Projeto Financeiro - Agência Bancária com Máquinas Virtuais no Azure

Este projeto demonstra como configurar uma infraestrutura de uma agência bancária utilizando Máquinas Virtuais (VMs) na Azure com foco em segurança, escalabilidade e segmentação.

## 🎯 Objetivo

Implementar uma arquitetura de rede segura e escalável para agências bancárias, simulando caixas eletrônicos, servidores internos e acesso remoto seguro.

## 🧱 Componentes

- Azure Virtual Network (VNet)
- Sub-redes: Frontend, Backend, JumpBox
- Máquinas Virtuais: Servidor de Aplicação, Banco de Dados, Bastion
- Network Security Groups (NSG)
- Azure Bastion (opcional)

## 📁 Estrutura

```
azure-agency-vm-project/
│
├── templates/           # Arquivos Bicep
├── docs/                # Documentação
├── scripts/             # Scripts de automação
```

## 🚀 Como Usar

```bash
az deployment sub create --location eastus --template-file templates/main.bicep
```

## 🔐 Segurança

- Acesso limitado via NSG
- Deploy seguro via JumpBox ou Bastion
- Senhas protegidas com Key Vault (futuramente)

## 📜 Licença

MIT
