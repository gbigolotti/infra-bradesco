# Script PowerShell para deploy do projeto

az group create --name rg-bank-agency --location eastus
az deployment group create --resource-group rg-bank-agency --template-file ../templates/main.bicep
